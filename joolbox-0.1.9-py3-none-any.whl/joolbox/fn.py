
class GlobalImport:
    def __enter__(self):
        return self
    def __exit__(self, *args):
        import inspect
        collector = inspect.getargvalues(inspect.getouterframes(inspect.currentframe())[1][0]).locals
        globals().update(collector)


def import_all():
    with GlobalImport():
        ## will fire a warning as its bad practice for python. 
        import numpy as np
        import pandas as pd
        try:
            import pencilbox as pb
        except():
            pass
        import logging
        import seaborn as sns
        import matplotlib.pyplot as plt
        from datetime import datetime
        from datetime import timedelta
        from pytz import timezone
        pd.set_option('display.max_columns', None)
        pd.set_option('display.max_rows', None)
        from sklearn.cluster import KMeans
        from scipy.stats import zscore
        from numpy import asarray
        from sklearn.preprocessing import MinMaxScaler
        from IPython.display import display
        import os
        import json
        from typing import Callable
        from functools import partial
        from scipy.stats import linregress
        import math
        import matplotlib.ticker as mtick


import_all()

def fn_read_gsheet(sheet_id, sheet_name):
    try:
        df_out = pb.from_sheets(sheet_id, sheet_name)
    except():
        df_out = pb.from_sheets(sheet_id, sheet_name, service_account="service_account")
    return df_out

def redcon():
    return pb.get_connection("redpen").connect()


def hello():
    print("Hello World")

def fn_qsv(qkey, q={}, params={}, read_from_csv=True):
    if (len(q) == 0):
        return pd.DataFrame()

    query = q[qkey]

    for key, val in params.items():
        query = query.replace(key, val)

    fpara = json.dumps(params).replace("{","_").replace("}","").replace(": ", "_").replace("\"","").replace(", ", "_")
    if (fpara == "_"):
        fpara = ""
    fpath = f"qdata/{qkey}{fpara}.csv"

    if(not read_from_csv) or (not os.path.exists(fpath)):
        if not os.path.exists('qdata'):
            os.makedirs('qdata')

        df = pd.read_sql(sql=query, con=redcon())
        df.to_csv(fpath, index = False)

    #reading from file
    df = pd.read_csv(fpath, index_col=False, low_memory=False)
    return df


fn_q = partial(fn_qsv, read_from_csv = False)




def remove_outlier(df_in, col_name):
    q1 = df_in[col_name].quantile(0.25)
    q3 = df_in[col_name].quantile(0.75)
    iqr = q3-q1 #Interquartile range
    fence_low  = q1-1.5*iqr
    fence_high = q3+1.5*iqr
    df_out = df_in.loc[(df_in[col_name] > fence_low) & (df_in[col_name] < fence_high)]
    return df_out


def remove_outliers(df_in, col_name_list, iqr_multiple=1.5):
    for col_name in col_name_list:
        q1 = df_in[col_name].quantile(0.25)
        q3 = df_in[col_name].quantile(0.75)
        iqr = q3-q1 #Interquartile range
        fence_low  = q1-iqr_multiple*iqr
        fence_high = q3+iqr_multiple*iqr
        df_out = df_in.loc[(df_in[col_name] > fence_low) & (df_in[col_name] < fence_high)]
    return df_out


def get_ntile_rnk_output(df_in, col_name, cuts=100, cname='Ntile'):
    df_out = df_in.copy()
    df_out[cname] = pd.qcut(df_out[col_name].rank(method='first'), cuts, labels = range(1, cuts + 1))
    df_out[cname] = df_out[cname].astype(float)
    conditions = [
                (df_out[cname] >=0) & (df_out[cname] <= 6),
              (df_out[cname] >=7) & (df_out[cname] <= 14),
              (df_out[cname] >=15) & (df_out[cname] <= 23),
              (df_out[cname] >=24) & (df_out[cname] <= 36),
              (df_out[cname] >=37) & (df_out[cname] <= 55),
              (df_out[cname] >=56) & (df_out[cname] <= 75),
              (df_out[cname] >=76) & (df_out[cname] <= 86),
              (df_out[cname] >=87) & (df_out[cname] <= 94),
                (df_out[cname] >=95) & (df_out[cname] <= 100)
             ]
    choices = [0,1,2,3,4,5,6,7,8]
    df_out['rnk'] = np.select(conditions, choices)
    return df_out


def get_ntile_output(df_in, col_name, cuts=100, cname='Ntile'):
    df_out = df_in.copy()
    df_out[cname] = pd.qcut(df_out[col_name].rank(method='first'), cuts, labels = range(1, cuts + 1))
    df_out[cname] = df_out[cname].astype(float)
    return df_out


def make_flat_index(df_in):
    df_in.columns = ["_".join(a) for a in df_in.columns.to_flat_index()]
    return df_in

def pareto_test(df_in, col_name):
    df = get_ntile_output(df_in, col_name)
    gdf = pd.pivot_table(df, values = [col_name], index =['Ntile'],
                         columns =[], aggfunc = {col_name: [np.sum, 'count']}).reset_index()
    gdf.columns = ["_".join(a) for a in gdf.columns.to_flat_index()]
    gdf.rename({'Ntile_': 'Ntile'}, axis=1, inplace=True)
    col_name_sum = f"{col_name}_sum"
    col_name_count = f"{col_name}_count"
    
    gdf['top_x_perc'] = 100 - gdf['Ntile'] + 1
    gdf['contribution_perc'] = round((gdf[col_name_sum]/gdf[col_name_sum].sum())*100,1)
    gdf[col_name_sum] = gdf[col_name_sum].round(2)
    gdf['upto_contribution_perc'] = gdf.apply(lambda x: gdf[gdf['Ntile']>=x['Ntile']]['contribution_perc'].sum(),axis=1)
    gdf[f"upto_{col_name_sum}"] = gdf.apply(lambda x: gdf[gdf['Ntile']>=x['Ntile']][col_name_sum].sum(),axis=1)
    gdf[f"upto_{col_name_count}"] = gdf.apply(lambda x: gdf[gdf['Ntile']>=x['Ntile']][col_name_count].sum(),axis=1)
    
    cols = ['top_x_perc', 'upto_contribution_perc', f"upto_{col_name_sum}", f"upto_{col_name_count}", 'contribution_perc', col_name_sum, col_name_count, 'Ntile']
    gdf = gdf[cols]
    
    return gdf.sort_values('top_x_perc')


def pareto_chart(df_in, col_name, by='', title='', figsize=(15,5), max_display_count = None, showlabels = False):
    df = df_in.sort_values(by=col_name,ascending=False)
    df["cumpercentage"] = (df[col_name].cumsum()/df[col_name].sum())*100
    if max_display_count != None:
        df = df.head(max_display_count)
    fig, ax = plt.subplots(figsize=figsize)
    plt.xticks(rotation=90)
    fig.suptitle(title)
    ax.bar(df[by], df[col_name], color="C0")
    ax2 = ax.twinx()
    ax2.plot(df[by], df["cumpercentage"], color="C1", marker="D", ms=7)
    ax2.yaxis.set_major_formatter(mtick.PercentFormatter())
    # ax2.line_label(ax2.containers[0], fmt='%.2f%%')
    if showlabels:
        ax.bar_label(ax.containers[0])
    ax.tick_params(axis="y", colors="C0")
    ax2.tick_params(axis="y", colors="C1")
    plt.xticks(rotation=90)
    plt.show()


def describe_basis(df_in, col_name, col_seq):
    df_result = pd.DataFrame()
    if(col_name not in col_seq):
            col_seq.append(col_name)
    for val in sorted(list(df_in[col_name].unique())):
        df_work = df_in[col_seq]
        df2 = df_work[df_work[col_name]==val]
#         df2 = remove_outliers(df2, col_seq)
        df_out = df2.describe()
#         df_out['index1'] = df_out.index
        df_out.reset_index(level=0, inplace=True)
        df_out[col_name] = val
        df_out.sort_values(by=col_name, inplace = True)
        cols = df_out.columns
        df_out[cols[1:]] = df_out[cols[1:]].apply(pd.to_numeric, errors='coerce')
#         df_out = df_out.astype('float64')
        df_result = df_result.append(df_out, ignore_index=True)
    return df_result.pivot_table(index=col_name, columns=["index"], values=df_result.columns.difference(["index", col_name]))
     


class MyKmeanWay:
#     Within-Cluster-Sum-of-Squares
    def __init__(self, data, mparas=None, no_of_clusters=3):
        self.data = data
        self.mparas = mparas
        self.no_of_clusters = no_of_clusters
        if(mparas==None):
            self.selected_data = data
        else:
            self.selected_data = data[mparas]
    
    def get_kmeans_data(self, no_of_clusters: int=None):
        if(no_of_clusters==None):
            no_of_clusters=self.no_of_clusters
        self.kmeans = KMeans(no_of_clusters)
        identified_clusters = self.kmeans.fit_predict(self.selected_data)
        data_with_clusters = self.data.copy()
        data_with_clusters['Clusters'] = identified_clusters 
        return data_with_clusters
        
    def set_no_of_clusters(self, no_of_clusters):
        self.no_of_clusters = no_of_clusters
        
    def show_elbow(self):
        wcss=[]
        for i in range(1,10):
            kmeans = KMeans(i)
            kmeans.fit(self.selected_data.apply(zscore))
            wcss_iter = kmeans.inertia_
            wcss.append(wcss_iter)
        number_clusters = range(1,10)
        ax = sns.lineplot(x=number_clusters, y=wcss)
        ax.set_title('The Elbow title')
        ax.set_xlabel('Number of clusters')
        ax.set_ylabel('WCSS')
        plt.show()

class RfmWay:
    def __init__(self, df_in, rfm_cols, rfm_cuts, adjustment=0, adjustment_cols=None):
        self.df_in = df_in
        self.rfm_cols = rfm_cols
        self.rfm_cuts = rfm_cuts
        self.df_result = df_in
        self.rnks = []
        for col, cuts in zip(rfm_cols, rfm_cuts):
#             print(f"cuts: {cuts}")
            self.rnks.append(f'rnk_{col}')
            self.df_result = self.__get_ntile_output(self.df_result, col, cname=f'rnk_{col}', cuts = cuts)
            self.df_result['rnk'] = self.df_result[self.rnks].sum(axis=1) - adjustment
            if(adjustment_cols is not None):
                self.df_result['rnk'] = self.df_result['rnk'] - self.df_result[adjustment_cols].sum(axis=1)
#                 self.df_result['rnk'] = np.where(self.df_result['rnk']<0,0,self.df_result['rnk'])
            self.df_result['rnk'] = np.where(self.df_result['rnk']<0,0,self.df_result['rnk'])
    
    def set_new_adjustment(adjustment, adjustment_cols=None):
        self.df_result['rnk'] = self.df_result[self.rnks].sum(axis=1) - adjustment
        if(adjustment_cols is not None):
            self.df_result['rnk'] = self.df_result['rnk'] - self.df_result[adjustment_cols].sum(axis=1)
            self.df_result['rnk'] = np.where(self.df_result['rnk']<0,0,self.df_result['rnk'])
            
        
    def describe(self, col_seq):
        return self.__describe_basis(self.df_result, "rnk", col_seq)
    
#     def set_df_result(self, df_in):
#         self.df_result = df_in.copy()
    
    @staticmethod
    def __describe_basis(df_in, col_name, col_seq):
        df_result = pd.DataFrame()
        if(col_name not in col_seq):
            col_seq.append(col_name)
        for val in sorted(list(df_in[col_name].unique())):
            df_work = df_in[col_seq]
            df2 = df_work[df_work[col_name]==val]
    #         df2 = remove_outliers(df2, col_seq)
            df_out = df2.describe()
    #         df_out['index1'] = df_out.index
            df_out.reset_index(level=0, inplace=True)
            df_out[col_name] = val
            df_out.sort_values(by=col_name, inplace = True)
            cols = df_out.columns
            df_out[cols[1:]] = df_out[cols[1:]].apply(pd.to_numeric, errors='coerce')
    #         df_out = df_out.astype('float64')
            df_result = df_result.append(df_out, ignore_index=True)
        return df_result.pivot_table(index=col_name, columns=["index"], values=df_result.columns.difference(["index", col_name]))
   
    @staticmethod
    def __get_ntile_output(df_in, col_name, cuts=100, cname='Ntile'):
        df_out = df_in.copy()
        df_out[cname] = pd.qcut(df_out[col_name].rank(method='first'), cuts, labels = range(1, cuts + 1))
        df_out[cname] = df_out[cname].astype(float)
        return df_out
    
    @staticmethod
    def __remove_outliers(df_in, col_name_list, iqr_multiple=1.5):
        for col_name in col_name_list:
            q1 = df_in[col_name].quantile(0.25)
            q3 = df_in[col_name].quantile(0.75)
            iqr = q3-q1 #Interquartile range
            fence_low  = q1-iqr_multiple*iqr
            fence_high = q3+iqr_multiple*iqr
            df_out = df_in.loc[(df_in[col_name] > fence_low) & (df_in[col_name] < fence_high)]
        return df_out
    
    def rnk_plot(self, axes=None):
        sns.histplot(ax=axes, data=self.df_result, x=self.df_result['rnk'])
        
    def rnk_share_plot(self, axes=None):
        sns.histplot(ax=axes, data=self.df_result, x=self.df_result['rnk'])
        
    
    def line_plot(self, col_seq, col_name="rnk", fig_size=(20,10), title=None):
        
        wdf = self.describe(col_seq)
        if(col_name in col_seq):
            col_seq.remove(col_name)
        
        no_of_fig_cols = 4
        ln = len(col_seq)
        fig, axes = plt.subplots(int(ln/no_of_fig_cols)+1, min(ln,no_of_fig_cols), figsize=fig_size)
        
#         print(col_seq)
        for index, col in enumerate(col_seq):
            ax0 = int(index/no_of_fig_cols)
            ay0 = index - int(index/no_of_fig_cols)*no_of_fig_cols
            tdf = wdf.loc[:,col]
            tdf = tdf[tdf.columns.difference(["count", "max", "25%", "75%", "min"])]
#             fdf.reset_index(level=0, inplace=True)
            fdf = tdf.stack().reset_index().rename(columns={0: "values"})
            if(int(ln/no_of_fig_cols+1)<=1):
                sns.lineplot(ax=axes[index], x=fdf[col_name], hue="Index", data=fdf).set_title(col)
            else:
                sns.lineplot(ax=axes[ax0, ay0], data=fdf, x=col_name, y="values", hue="index").set_title(col)
#                 sns.boxplot(ax=axes[ax0, ay0], x=fdf[col_name], hue="Index", data=fdf).set_title(col)
            
        fig.tight_layout()
        if(title is not None):
            fig.suptitle(title, size=16)
            fig.subplots_adjust(top=0.88)
        
        plt.show()
            
    @staticmethod
    def __show_values_on_bars(axs):
        def _show_on_single_plot(ax):        
            for p in ax.patches:
                _x = p.get_x() + p.get_width() / 2
                _y = p.get_y() + p.get_height()
                value = '{:.2f}'.format(p.get_height())
                ax.text(_x, _y, value, ha="center", va='top',rotation=90) 

        if isinstance(axs, np.ndarray):
            for idx, ax in np.ndenumerate(axs):
                _show_on_single_plot(ax)
        else:
            _show_on_single_plot(axs)
       
    def count_plot(self, title="Absolute", fig_size = (5,5)):
        wdf = self.describe(self.rfm_cols)
        
        tdf = wdf.loc[:,self.rfm_cols[0]]
        tdf = tdf.stack().reset_index().rename(columns={0: "values"})
        tdf = tdf[tdf["index"]=="count"]
        
        fig, axes = plt.subplots(1,1, figsize=fig_size)
        sns.barplot(x = 'rnk',
            y = 'values',
            data = tdf)
#         plt.xticks(rotation=70)
        plt.tight_layout()
        self.__show_values_on_bars(axes)
        if(title is not None):
            fig.suptitle(title, size=16)
            fig.subplots_adjust(top=0.88) 
        plt.show()
        
    def count_plot_perc(self, title="%Age", fig_size = (5,5)):
        wdf = self.describe(self.rfm_cols)
        tdf = wdf.loc[:,self.rfm_cols[0]]
        tdf["count%"] = (tdf["count"]/tdf["count"].sum())*100
        tdf = tdf.stack().reset_index().rename(columns={0: "values"})
        tdf = tdf[tdf["index"]=="count%"]
        fig, axes = plt.subplots(1,1, figsize=fig_size)
        sns.barplot(x = 'rnk',
            y = 'values',
            data = tdf)
#         plt.xticks(rotation=70)
        plt.tight_layout()
        self.__show_values_on_bars(axes) 
        if(title is not None):
            fig.suptitle(title, size=16)
            fig.subplots_adjust(top=0.88)
        plt.show()
        
    def box_plot(self, col_seq=None, col_name="rnk", fig_size=(10,5)):
        if(col_name not in col_seq):
            col_seq.append(col_name)
            
        if(col_seq==None):
            col_seq = self.df_result.columns
       
        ndf = self.df_result[col_seq]
#         ndf = pd.DataFrame()
#         for val in sorted(list(wdf[col_name].unique())):
#             df2 = wdf[wdf[col_name]==val]
#             df2 = self.__remove_outliers(df2, col_seq, iqr_multiple=1.5)
#             ndf = ndf.append(df2, ignore_index=True)
        
#         print(list(ndf.columns))
        
       
#         ndf[col_name] = ndf[col_name].astype('category')
        no_of_fig_cols = 4
        ln = len(col_seq) - 1
        fig_size_x = 4
        fig_size_y = 2 #(ln/no_of_fig_cols+1)*5
        fig, axes = plt.subplots(int(ln/no_of_fig_cols)+1, min(ln,no_of_fig_cols), figsize=fig_size)
        
        ls = [item for item in col_seq if item not in [col_name]]
        for index, col in enumerate(ls):
            ax0 = int(index/no_of_fig_cols)
            ay0 = index - int(index/no_of_fig_cols)*no_of_fig_cols
            max(0,(index - no_of_fig_cols*(ln/no_of_fig_cols)))
#             print(f"{ax0},{ay0}")
            if(int(ln/no_of_fig_cols+1)<=1):
                sns.boxplot(ax=axes[index], data=ndf, x=col_name, y=col, showfliers = False).set_title(col)
            else:
                sns.boxplot(ax=axes[ax0, ay0], data=ndf, x=col_name, y=col, showfliers = False).set_title(col)
        fig.tight_layout()
        plt.show()