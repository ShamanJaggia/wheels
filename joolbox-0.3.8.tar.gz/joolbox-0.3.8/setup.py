from setuptools import setup

setup(
    name='joolbox',
    packages=['joolbox'],
    description='Analytics toolkit',
    version='0.3.8',
    url='https://github.com/ShamanJaggia/joolbox',
    author='shaman jaggia',
    author_email='shaman.jaggia@gmail.com',
    keywords=['pip', 'joolbox'],
    install_requires=[
        "numpy",
        "pandas",
        "matplotlib",
        "seaborn",
        "sklearn",
        "scipy",
        "typing",
        "pydrive",
        "openpyxl==3.0.1"
    ]
)
# pip install --upgrade setuptools wheel
# python3 setup.py sdist bdist_wheel
