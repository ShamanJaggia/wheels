# from slack_sdk import WebClient
# from slack_sdk.errors import SlackApiError
# import logging

# # token = "xoxb-2526871921-2281166404336-1pUB0GtxhKBtGpLbaJ1QRCkv"
# token = ""

# def __create_image__(
#     df, file_name, columnorder, columnwidth, width, height, color_df=None, scale=1
# ):
#     fig = go.Figure(
#         data=[
#             go.Table(
#                 columnorder=columnorder,
#                 columnwidth=columnwidth,
#                 header=dict(
#                     values=list(df.columns),
#                     fill_color="paleturquoise",
#                     line_color="black",
#                     align="center",
#                 ),
#                 cells=dict(
#                     values=df.transpose(),
#                     fill_color=df.transpose().applymap(lambda x: "white")
#                     if type(color_df) != pd.DataFrame
#                     else color_df.transpose(),
#                     line_color="black",
#                     align="center",
#                 ),
#             )
#         ]
#     )
#     fig.update_layout(autosize=False, width=width, height=height)
#     fig.write_image(file_name, scale=scale)
#     return file_name


# def send_slack_df(
#     channel_id,
#     columnorder,
#     columnwidth,
#     width,
#     height,
#     message=None,
#     df=None,
#     color_df=None,
#     scale=1,
#     token=token,
# ):
#     send_slack_message(
#         channel_id=channel_id,
#         token=token,
#         file=__create_image__(
#             df,
#             file_name="slackdf.png",
#             columnorder=columnorder,
#             columnwidth=columnwidth,
#             width=width,
#             height=height,
#             color_df=color_df,
#             scale=scale,
#         ),
#         message=message,
#     )


# def send_slack_message(channel_id, message=None, file=None, token=token):
#     client = WebClient(token=token)
#     if message != None and file == None:
#         try:
#             response = client.chat_postMessage(channel=channel, text=message)
#         except SlackApiError as e:
#             # You will get a SlackApiError if "ok" is False
#             assert e.response["error"]  # str like 'invalid_auth', 'channel_not_found'

#     if file != None:
#         try:
#             # Call the files.upload method using the WebClient
#             # Uploading files requires the `files:write` scope
#             result = client.files_upload(
#                 channels=channel_id,
#                 initial_comment="PFA" if message == None else message,
#                 file=file,
#             )
#             # Log the result
#         #     logging.info(result)
#         except SlackApiError as e:
#             logging.error("Error uploading file: {}".format(e))