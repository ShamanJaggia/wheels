
from slack_sdk import WebClient
from slack_sdk.errors import SlackApiError
import logging
from joolbox import gd
# import plotly.graph_objects as go
# import pandas as pd

class SlackWrapper:
    def __init__(self):
        self.token = gd.get_content_from_vault('slack token')

    def send_slack_message(self, channel_id, message=None, file=None, token=None):
        if token is None:
            token = self.token
            if token is None:
                raise Exception("slack token is mandatory")
        client = WebClient(token=token)
        if ((message is not None) and (file is None)):
            try:
                client.chat_postMessage(channel=channel_id, text=message)
            except SlackApiError as e:
                # You will get a SlackApiError if "ok" is False
                assert e.response["error"]  # str like 'invalid_auth', 'channel_not_found'

        if file is not None:
            try:
                # Call the files.upload method using the WebClient
                # Uploading files requires the `files:write` scope
                client.files_upload(
                    channels=channel_id,
                    initial_comment="PFA" if message is None else message,
                    file=file,
                )
                # Log the result
            #     logging.info(result)
            except SlackApiError as e:
                logging.error("Error uploading file: {}".format(e))
        # @staticmethod
    # def __create_image__(
    #     df, file_name, columnorder, columnwidth, width, height, color_df=None, scale=1
    # ):
    #     fig = go.Figure(
    #         data=[
    #             go.Table(
    #                 columnorder=columnorder,
    #                 columnwidth=columnwidth,
    #                 header=dict(
    #                     values=list(df.columns),
    #                     fill_color="paleturquoise",
    #                     line_color="black",
    #                     align="center",
    #                 ),
    #                 cells=dict(
    #                     values=df.transpose(),
    #                     fill_color=df.transpose().applymap(lambda x: "white")
    #                     if type(color_df) is not pd.DataFrame
    #                     else color_df.transpose(),
    #                     line_color="black",
    #                     align="center",
    #                 ),
    #             )
    #         ]
    #     )
    #     fig.update_layout(autosize=False, width=width, height=height)
    #     fig.write_image(file_name, scale=scale)
    #     return file_name

    # def send_slack_df(
    #     self,
    #     channel_id,
    #     columnorder,
    #     columnwidth,
    #     width,
    #     height,
    #     message=None,
    #     df=None,
    #     color_df=None,
    #     scale=1,
    #     token=None,
    # ):
        # if token is None:
        #     token = self.token
        #     if token is None:
        #         raise Exception("slack token is mandatory")
        # self.send_slack_message(
        #     channel_id=channel_id,
        #     token=token,
        #     file=self.__create_image__(
        #         df,
        #         file_name="slackdf.png",
        #         columnorder=columnorder,
        #         columnwidth=columnwidth,
        #         width=width,
        #         height=height,
        #         color_df=color_df,
        #         scale=scale,
        #     ),
        #     message=message,
        # )
