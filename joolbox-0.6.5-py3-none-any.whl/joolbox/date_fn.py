from datetime import datetime
from datetime import timedelta
import numpy as np

dt_fmt = "%Y-%m-%d"
dtm_fmt = "%Y-%m-%d %H:%M:%S"

def now():
    today = (datetime.now() + timedelta(hours=5.5)).strftime(dtm_fmt)
    return today

def yesterday():
    yesterday = (datetime.now() - timedelta(days=1) + timedelta(hours=5.5)).strftime(dt_fmt)
    return yesterday

def today():
    today = (datetime.now() + timedelta(hours=5.5)).strftime(dt_fmt)
    return today

def today_x(x):
    today = (datetime.now() - timedelta(days=x) + timedelta(hours=5.5)).strftime(dt_fmt)
    return today

def today_7():
    today = today_x(7)
    return today

def today_14():
    today = today_x(14)
    return today

def today_21():
    today = today_x(21)
    return today

def today_28():
    today = today_x(28)
    return today

def week():
    return fn_week_tuple(today())

def week_x(x):
    any_day_of_x_week = today_x(x*7)
    return fn_week_tuple(any_day_of_x_week)

def current_week():
    return week()

def last_week():
    return week_x(1)

def previous_week():
    return week_x(1)

def week_1():
    return week_x(1)

def week_2():
    return week_x(2)

def week_3():
    return week_x(3)

def week_4():
    return week_x(4)

def month():
    return (fn_first_day_of_month(today()), fn_last_day_of_month(today()))

def month_x(x):
    first_day_of_month = fn_first_day_of_month(today())
    for i in np.arange(1, x+1):
        last_day_of_prev_month = (datetime.strptime(first_day_of_month, dt_fmt) - timedelta(days=1)).strftime(dt_fmt)
        first_day_of_month = fn_first_day_of_month(last_day_of_prev_month)
    last_day_of_month = fn_last_day_of_month(first_day_of_month)
    return (first_day_of_month, last_day_of_month)

def current_month():
    return month()

def last_month():
    return month_x(1)

def previous_month():
    return month_x(1)

def month_1():
    return month_x(1)

def month_2():
    return month_x(2)

def month_3():
    return month_x(3)

def month_4():
    return month_x(4)

def fn_week_tuple(datestr):
    '''
    Gives start date and end of monday to sunday week basis string input
    example. 2022-04-19 will give you output as ('2022-04-18', '2022-04-24')
    '''
    dt = datetime.strptime(datestr, '%Y-%m-%d')
    start = dt - timedelta(days=dt.weekday())
    end = start + timedelta(days=6)
    return (start.strftime(dt_fmt), end.strftime(dt_fmt))


def fn_last_day_of_month(datestr):
    # this will never fail
    # get close to the end of the month for any day, and add 4 days 'over'
    any_day = datetime.strptime(datestr, '%Y-%m-%d')
    next_month = any_day.replace(day=28) + timedelta(days=4)
    # subtract the number of remaining 'overage' days to get last day of current month, or said programattically said, the previous day of the first of next month
    return (next_month - timedelta(days=next_month.day)).strftime(dt_fmt)

def fn_first_day_of_month(datestr):
    any_day = datetime.strptime(datestr, '%Y-%m-%d')
    return any_day.replace(day=1).strftime(dt_fmt)

def date_split(start, end, intv):
    def date_range_generator(start, end, intv):
        start = datetime.strptime(start, dt_fmt)
        end = datetime.strptime(end, dt_fmt)
        diff = (end - start) / intv
        for i in range(intv):
            if(i != 0):
                x = ((start + diff * i) - timedelta(days=1)).strftime(dt_fmt)
                yield x
            x = (start + diff * i).strftime(dt_fmt)
            yield x
        yield end.strftime(dt_fmt)
    dt_lst = list(date_range_generator(start, end, intv))
    return list(zip(dt_lst[::2], dt_lst[1::2]))

def datetime_split(start, end, intv):
    def date_range_generator(start, end, intv):
        start = datetime.strptime(start, dtm_fmt)
        end = datetime.strptime(end, dtm_fmt)
        diff = (end - start) / intv
        for i in range(intv):
            if(i != 0):
                x = ((start + diff * i) - timedelta(seconds=1)).strftime(dtm_fmt)
                yield x
            x = (start + diff * i).strftime(dtm_fmt)
            yield x
        yield end.strftime(dtm_fmt)
    dt_lst = list(date_range_generator(start, end, intv))
    return list(zip(dt_lst[::2], dt_lst[1::2]))
