import seaborn as sns
import matplotlib.pyplot as plt
from datetime import datetime
from datetime import timedelta
import numpy as np
import pandas as pd
import matplotlib.ticker as mtick


def contribution_pie(df, x=None, y=None, ax=None, title=''):
    fig, ax = plt.subplots(1, 1, figsize=(15, 5))
    fig.suptitle(title)
    cdf = pd.pivot_table(df.round(2), index=[x], values=[y], columns=[], aggfunc=np.sum).reset_index()
    plt.pie(cdf[y], labels=cdf[x], autopct='%.0f%%')
    plt.show()

def contribution_bar(df, x=None, y=None, ax=None, showlabels=True):
    cdf = pd.pivot_table(df.round(2), index=[x], values=[y], columns=[], aggfunc=np.sum).reset_index()
    sns.barplot(data=cdf, x=x, y=y, ax=ax)
    if showlabels:
        ax.bar_label(ax.containers[0], color='C0')
    return ax


def pareto_chart(df_in, x='', y=None,
                 title='', figsize=(15, 5),
                 max_display_count=None,
                 show_right_axis=True,
                 showlabels=True, c0='C0', c1='C1'):
    df_in = pd.pivot_table(df_in, index=[x], values=[y], columns=[], aggfunc=np.sum).reset_index()
    df = df_in.sort_values(y, ascending=False)
    df["cumpercentage"] = (df[y].cumsum()/df[y].sum())*100
    if max_display_count is not None:
        df = df.head(max_display_count)
    fig, ax = plt.subplots(figsize=figsize)
    ax.set_title(title)
    ax.tick_params(axis="y", colors=c0)
    ax.set_xticks(ax.get_xticks().tolist())
    ax.set_xticklabels(labels=ax.get_xticklabels(), rotation=90)
    if show_right_axis:
        ax2 = ax.twinx()
        ax2.yaxis.set_major_formatter(mtick.PercentFormatter())
        # ax2.line_label(ax2.containers[0], fmt='%.2f%%')
        ax2.tick_params(axis="y", colors=c1)
        sns.lineplot(x=x, y="cumpercentage", data=df, ax=ax2, color=c1, marker="D", ms=7)
    sns.barplot(x=x, y=y, data=df, ax=ax, color=c0)
    if showlabels:
        ax.bar_label(ax.containers[0], color=c0)
        if show_right_axis:
            for item in df.groupby('cumpercentage'):
                for x1, y1 in item[1][[x, 'cumpercentage']].values:
                    # print(x1,y1,y1)
                    plt.text(x1, y1+2, "{0:.1f}%".format(y1), color=c1)
    plt.show()

def lineplot(df, x=None, y=None, ax=None, hue=None, showlabels=False):
    if hue is None:
        cdf = pd.pivot_table(df.round(2), index=[x], values=[y], columns=[], aggfunc=np.sum).reset_index()
    else:
        cdf = pd.pivot_table(df.round(2), index=[x, hue], values=[y], columns=[], aggfunc=np.sum).reset_index()
    sns.lineplot(data=cdf, x=x, y=y, hue=hue, ax=ax)
    return ax

